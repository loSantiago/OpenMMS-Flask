class WSHost:

    def __init__(self):
        self.URL = "https://ava.ethoson.com.br/webservice/rest/server.php"
        self.TOKEN = "630a8a74add6feca08e10597be94e404"

    #Return URL
    def url(self):
        return self.URL
    
    #Return TOKEN MOODLE WEBSERVICE
    def token(self):
        return self.TOKEN