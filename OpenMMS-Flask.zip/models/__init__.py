def __str__():
    return "Models, conexão do banco dados NoSQL."